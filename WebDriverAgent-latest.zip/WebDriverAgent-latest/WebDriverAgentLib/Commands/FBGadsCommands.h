//
//  FBGadsCommands.h
//  WebDriverAgent
//
//  Created by Nikola Shabanov on 17.09.25.
//  Copyright © 2025 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FBCommandHandler.h"

NS_ASSUME_NONNULL_BEGIN

@interface FBGadsCommands : NSObject <FBCommandHandler>

@end

NS_ASSUME_NONNULL_END

