**Warning:**

These issues are not tracked. Please create new issues in the main Appium
repository: https://github.com/appium/appium/issues/new
